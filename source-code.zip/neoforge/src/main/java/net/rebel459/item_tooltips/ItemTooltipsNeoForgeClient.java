package net.rebel459.item_tooltips;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(value = ItemTooltips.MOD_ID, dist = Dist.CLIENT)
public class ItemTooltipsNeoForgeClient {

    public ItemTooltipsNeoForgeClient(IEventBus modEventBus) {
        ItemTooltips.init();
    }
}