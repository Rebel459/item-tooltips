package net.rebel459.item_tooltips.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.gui.screens.inventory.EnchantmentScreen;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.enchantment.Enchantment;
import net.rebel459.item_tooltips.config.ITConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Mixin(EnchantmentScreen.class)
public class EnchantmentScreenMixin {
	@WrapOperation(method = "extractRenderState", at = @At(value = "INVOKE", target = "java/util/List.add(Ljava/lang/Object;)Z", ordinal = 0))
	private boolean enchanting_table_descriptions_addTooltipsToTable(List<Component> instance, Object text, Operation<Boolean> operation, @Local Optional<Holder.Reference<Enchantment>> enchantment) {
		boolean bl = operation.call(instance,text);
		if (!ITConfig.get.enchantments.enchanting_table_descriptions) return bl;
		Identifier enchantmentId = enchantment.get().unwrapKey().get().identifier();
		MutableComponent description = (Component.literal(""))
				.append(Component.translatable(ITConfig.get.enchantments.prefix.text).withColor(ITConfig.get.enchantments.prefix.color))
				.append(Component.translatable("enchantment." + enchantmentId.getNamespace() + "." + enchantmentId.getPath() + ".desc").withColor(ITConfig.get.enchantments.color));
		if (!Objects.equals(description,description.getContents())) {
			return instance.add(description);
		} else {
			return bl;
		}
	}
}